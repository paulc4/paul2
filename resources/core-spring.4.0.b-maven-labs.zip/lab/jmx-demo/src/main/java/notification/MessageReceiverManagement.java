package notification;

public interface MessageReceiverManagement {

	public abstract int getMessageCount();

}