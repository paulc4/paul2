package notification;

public interface MessagePublisherManagement {

	void sendMessage(String message);

}
