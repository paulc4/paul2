package consumption;

public interface MessageCapable {

	String getMessage();
	
	void setMessage(String message);
	
	String reverseMessage();
}
