package config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class JmsInfrastructureConfig {

	//	TODO-01: Define an ActiveMQConnectionFactory.
	//	Use brokerURL "vm://embedded?broker.persistent=false" 

	//	TODO-02: Create two ActiveMQQueue beans, one for dining and one for confirmations.
	//	Use constructor injection to provide a unique name for each queue. 
	//	Remember the queue names you select, you will need them later. -->
	
}
