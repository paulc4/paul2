package traditional;

public interface MessageServiceMBean {

	String getMessage();
	
	void setMessage(String string);
	
	String reverseMessage();
}
